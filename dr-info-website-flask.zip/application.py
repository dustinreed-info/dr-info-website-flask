# from src import create_app
# from src.routes import app
# from src import create_app
# # from app import create_app

# application = create_app()
from flask import Flask
# from src.config import Config
from flask import render_template, flash, redirect, url_for
# from src import create_app

import os

class Config(object):
    SECRET_KEY = os.environ.get("SECRET_KEY")


# def create_app():
application = Flask(__name__)
application.config.from_object(Config)
    # return app


# app = create_app()


@application.route('/')
@application.route('/index')
@application.route('/home')
def index():
    return render_template('index.html', title='Home')
@application.route('/contact')
def contact():
    return render_template('contact.html')
@application.route('/about')
def about():
    return render_template('about.html')
@application.route('/certifications')
def certifications():
    return render_template('certifications.html')
@application.route('/resume')
def resume():
    return url_for('static', filename='Resume-Reed-Dustin.pdf')
@application.route('/projects')
def projects():
    return render_template('projects.html')




if __name__ == "__main__":
    application.run()